Installation:

Drag and drop the folder into your server's Resources/Server and Resources/Client directory.

Restart your server.

Type /setzone [radius] while in car in-game and start the mayhem!

==============================================================================================
COMMANDS
/setzone [radius] – Spawns the zone at your current location with a custom starting size.

/setzonespeed [meters] (per second) – Adjust how fast the circle closes (e.g., 0.5 for slow, 2.0 for rapid intensity).

/setzonelimit [radius] – Set the final size where the zone stops shrinking (e.g., set to 0 to close the zone completely).

/stopzone – Immediately cancels the event and removes the visual boundaries.

~Kengar