local zoneActive = false

function onChatMessage(player_id, player_name, message)
    
    local args = {}
    for word in string.gmatch(message, "%S+") do
        table.insert(args, word)
    end

    
    if args[1] == "/setzone" then
        local radius = tonumber(args[2]) or 100
        
        
        MP.TriggerClientEvent(player_id, "GetPosForZone", tostring(radius))
        
        print(player_name .. " is initiating a zone of radius " .. radius)
        return 1 
    end

    
    if args[1] == "/setzonespeed" then
        local speed = tonumber(args[2])
        if speed then
            
            MP.TriggerClientEvent(-1, "UpdateZoneSpeed", tostring(speed))
            print("Zone speed changed to " .. speed .. " by " .. player_name)
        else
            
            MP.SendChatMessage(player_id, "Usage: /setzonespeed [number, e.g. 0.5 or 2.0]")
        end
        return 1
    end

    -- NOWA KOMENDA: /setzonelimit [radius]
    if args[1] == "/setzonelimit" then
        local limit = tonumber(args[2])
        if limit then
            MP.TriggerClientEvent(-1, "UpdateZoneLimit", tostring(limit))
            print("Zone limit changed to " .. limit .. " by " .. player_name)
            MP.SendChatMessage(-1, "Zone limit set to: " .. limit .. "m")
        else
            MP.SendChatMessage(player_id, "Usage: /setzonelimit [number, e.g. 0 or 10]")
        end
        return 1
    end

    
    if args[1] == "/stopzone" then
        zoneActive = false
        MP.TriggerClientEvent(-1, "SyncZone", "stop") 
        print("Zone stopped by " .. player_name)
        return 1
    end
end

function OnReceivePosForZone(player_id, data)
    zoneActive = true
    MP.TriggerClientEvent(-1, "SyncZone", data)
    print("Zone started at coordinates: " .. data)
end

MP.RegisterEvent("onChatMessage", "onChatMessage")
MP.RegisterEvent("ReceivePosForZone", "OnReceivePosForZone")